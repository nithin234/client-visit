import React from 'react'
import './styles.css'

const Compare = ({products}) =>
  <div className="row compare">
    <div className="col-12 mt-5 text-center">
      <table className="table">
        <thead className="thead-default">
          <tr>
            <th></th>
            {products.map(product =>
              <th key={product.id}>
                {product.name}
              </th>
            )}
          </tr>
        </thead>
        <tbody>
          <tr className="price">
            <th scope="row">Premium</th>
            {products.map(product =>
              <td key={product.id} className="text-center">{product.price}</td>
            )}
          </tr>
          <tr className="condition">
            <th scope="row">Variable Excess</th>
            {products.map(product =>
              <td key={product.id} className={product.condition === "Used" ? "bg-red" : "bg-green"}>
                {product.condition}
              </td>
            )}
          </tr>
          <tr className="baby">
            <th scope="row">Baby Seat Replacement</th>
            {products.map(product =>
              <td key={product.id} className="text-center">{product.baby}</td>
            )}
          </tr>
        </tbody>
      </table>
    </div>
  </div>

export default Compare
